// EventPublisher interface:
// async publish(exchange, routingKey, message)
module.exports = {};
