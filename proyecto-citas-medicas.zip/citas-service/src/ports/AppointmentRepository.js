// AppointmentRepository (interface):
// async create({patientName, doctor, scheduledAt}) -> returns created row
// async list() -> returns array
module.exports = {};
