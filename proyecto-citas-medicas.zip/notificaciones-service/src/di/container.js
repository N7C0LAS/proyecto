// simple DI container placeholder
module.exports = {};
